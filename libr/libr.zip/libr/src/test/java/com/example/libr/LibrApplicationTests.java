package com.example.libr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrApplicationTests {

	@Test
	void contextLoads() {
	}

}
